# Unity village project

This directory contains the Unity project for the NPC Memory Village demo. It is arranged separately from the FastAPI backend at the repository root.

## Open and run

1. Install Unity Editor **6000.3.27f2** (or a compatible Unity 6.3 release).
2. In Unity Hub, choose **Add** and select this `NPCMemoryVillage` folder.
3. Wait for packages and assets to finish importing.
4. Open `Assets/Scenes/Village.unity`. If Unity asks to rebuild the generated demo scene, use **NPC Memory → Build Demo Village**.
5. Start the FastAPI and Ollama services as described in the backend README. The Unity `BackendConfig` defaults to `http://127.0.0.1:8001/chat`; update it if your backend is running elsewhere.
6. Press Play, enter a player ID, and use the same ID and NPC to continue that conversation history.

The project includes `Assets`, `Packages`, and `ProjectSettings` with Unity `.meta` files. Generated folders such as `Library`, `Temp`, `Logs`, and `UserSettings` are intentionally omitted; Unity recreates them on first open.
